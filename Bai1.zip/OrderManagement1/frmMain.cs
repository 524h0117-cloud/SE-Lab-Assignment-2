﻿using System;
using System.Windows.Forms;

namespace OrderManagement1
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void btnItem_Click(object sender, EventArgs e)
        {
            new frmItem().Show();
        }

        private void btnAgent_Click(object sender, EventArgs e)
        {
            new frmAgent().Show();
        }

        private void btnOrder_Click(object sender, EventArgs e)
        {
            new frmOrder().Show();
        }
    }
}