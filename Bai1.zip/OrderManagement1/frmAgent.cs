﻿using System;
using System.Windows.Forms;
using BLL;

namespace OrderManagement1
{
    public partial class frmAgent : Form
    {
        AgentBLL bll = new AgentBLL();
        int selectedId = -1;

        public frmAgent()
        {
            InitializeComponent();
        }

        private void frmAgent_Load(object sender, EventArgs e)
        {
            dgvAgent.DataSource = bll.GetAll();
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            dgvAgent.DataSource = bll.GetAll();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            bll.Insert(txtName.Text, txtAddress.Text);
            dgvAgent.DataSource = bll.GetAll();
        }

        private void dgvAgent_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                selectedId = Convert.ToInt32(dgvAgent.Rows[e.RowIndex].Cells["AgentID"].Value);
                txtName.Text = dgvAgent.Rows[e.RowIndex].Cells["AgentName"].Value.ToString();
                txtAddress.Text = dgvAgent.Rows[e.RowIndex].Cells["Address"].Value.ToString();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            bll.Update(selectedId, txtName.Text, txtAddress.Text);
            dgvAgent.DataSource = bll.GetAll();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            bll.Delete(selectedId);
            dgvAgent.DataSource = bll.GetAll();
        }
    }
}