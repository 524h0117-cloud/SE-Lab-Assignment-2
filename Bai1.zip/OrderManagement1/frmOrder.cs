﻿using System;
using System.Data;
using System.Windows.Forms;
using BLL;

namespace OrderManagement1
{
    public partial class frmOrder : Form
    {
        OrderBLL bll = new OrderBLL();
        DataTable dt = new DataTable();

        public frmOrder()
        {
            InitializeComponent();
        }

        private void frmOrder_Load(object sender, EventArgs e)
        {
            // load Agent
            cbAgent.DataSource = bll.GetAgents();
            cbAgent.DisplayMember = "AgentName";
            cbAgent.ValueMember = "AgentID";

            // load Item
            cbItem.DataSource = bll.GetItems();
            cbItem.DisplayMember = "ItemName";
            cbItem.ValueMember = "ItemID";

            // tạo bảng tạm
            dt.Columns.Add("ItemID");
            dt.Columns.Add("ItemName");
            dt.Columns.Add("Quantity");
            dt.Columns.Add("Price");

            dgvDetail.DataSource = dt;
        }

        // ADD ITEM
        private void btnAdd_Click(object sender, EventArgs e)
        {
            // 1. kiểm tra rỗng
            if (txtQty.Text.Trim() == "" || txtPrice.Text.Trim() == "")
            {
                MessageBox.Show("Nhập đầy đủ thông tin");
                return;
            }

            // 2. thêm vào bảng
            dt.Rows.Add(
                cbItem.SelectedValue,
                cbItem.Text,
                txtQty.Text,
                txtPrice.Text
            );

            // 3. reload lại grid (QUAN TRỌNG)
            dgvDetail.DataSource = null;
            dgvDetail.DataSource = dt;

            // 4. clear input
            txtQty.Clear();
            txtPrice.Clear();
        }

        // SAVE ORDER
        private void btnSave_Click(object sender, EventArgs e)
        {
            int agentId = Convert.ToInt32(cbAgent.SelectedValue);

            // tạo Order
            int orderId = bll.InsertOrder(agentId);

            // thêm từng dòng detail
            foreach (DataRow row in dt.Rows)
            {
                int itemId = Convert.ToInt32(row["ItemID"]);
                int qty = Convert.ToInt32(row["Quantity"]);
                float price = float.Parse(row["Price"].ToString());

                bll.InsertDetail(orderId, itemId, qty, price);
            }

            MessageBox.Show("Lưu đơn hàng thành công");

            dt.Clear();
        }
    }
}