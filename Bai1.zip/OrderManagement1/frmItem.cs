﻿using System;
using System.Windows.Forms;
using BLL;

namespace OrderManagement1
{
    public partial class frmItem : Form
    {
        ItemBLL bll = new ItemBLL();
        int selectedId = -1; // thêm dòng này

        public frmItem()
        {
            InitializeComponent();
        }

        private void frmItem_Load(object sender, EventArgs e)
        {
            dgvItem.DataSource = bll.GetAll();
        }
        // LOAD DATA
        private void btnLoad_Click(object sender, EventArgs e)
        {
            dgvItem.DataSource = bll.GetAll();
        }

        // ADD DATA
        private void btnAdd_Click(object sender, EventArgs e)
        {
            // 1. Kiểm tra rỗng
            if (txtName.Text.Trim() == "" || txtSize.Text.Trim() == "")
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin");
                return;
            }

            // 2. Thêm dữ liệu
            bll.Insert(txtName.Text, txtSize.Text);
            MessageBox.Show("Thêm thành công");

            // 3. Load lại bảng
            dgvItem.DataSource = bll.GetAll();

            // 4. Xóa ô nhập
            txtName.Clear();
            txtSize.Clear();
        }

        // CLICK ROW → ĐỔ DỮ LIỆU
        private void dgvItem_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                selectedId = Convert.ToInt32(dgvItem.Rows[e.RowIndex].Cells["ItemID"].Value);
                txtName.Text = dgvItem.Rows[e.RowIndex].Cells["ItemName"].Value.ToString();
                txtSize.Text = dgvItem.Rows[e.RowIndex].Cells["Size"].Value.ToString();

            }
        }

        // UPDATE
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            // 1. Phải chọn dòng
            if (selectedId == -1)
            {
                MessageBox.Show("Vui lòng chọn dòng cần sửa");
                return;
            }

            // 2. Không được rỗng
            if (txtName.Text.Trim() == "" || txtSize.Text.Trim() == "")
            {
                MessageBox.Show("Không được để trống");
                return;
            }

            // 3. Update
            bll.Update(selectedId, txtName.Text, txtSize.Text);
            MessageBox.Show("Cập nhật thành công");

            // 4. Load lại
            dgvItem.DataSource = bll.GetAll();
        }

        // DELETE
        private void btnDelete_Click(object sender, EventArgs e)
        {
            // 1. Phải chọn dòng
            if (selectedId == -1)
            {
                MessageBox.Show("Vui lòng chọn dòng cần xóa");
                return;
            }

            // 2. Xác nhận
            DialogResult result = MessageBox.Show(
                "Bạn có chắc muốn xóa?",
                "Xác nhận",
                MessageBoxButtons.YesNo);

            // 3. Nếu đồng ý
            if (result == DialogResult.Yes)
            {
                bll.Delete(selectedId);
                MessageBox.Show("Xóa thành công");

                dgvItem.DataSource = bll.GetAll();
            }
        }
    }
}