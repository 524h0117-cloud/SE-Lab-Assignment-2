﻿using System;
using System.Windows.Forms;
using BLL;

namespace OrderManagement1
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            UserBLL bll = new UserBLL();

            if (bll.Login(txtUser.Text, txtPass.Text))
            {
                MessageBox.Show("Đăng nhập thành công");

                frmMain f = new frmMain(); // 👉 mở MAIN
                f.Show();

                this.Hide(); // ẩn login
            }
            else
            {
                MessageBox.Show("Sai tài khoản hoặc mật khẩu");
            }
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {

        }
    }
}