﻿using DAL;
using System.Data;

namespace BLL
{
    public class AgentBLL
    {
        AgentDAL dal = new AgentDAL();

        public DataTable GetAll()
        {
            return dal.GetAll();
        }

        public void Insert(string name, string address)
        {
            dal.Insert(name, address);
        }

        public void Update(int id, string name, string address)
        {
            dal.Update(id, name, address);
        }

        public void Delete(int id)
        {
            dal.Delete(id);
        }
    }
}