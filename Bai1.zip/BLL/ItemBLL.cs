﻿using DAL;
using System.Data;

namespace BLL
{
    public class ItemBLL
    {
        ItemDAL dal = new ItemDAL();

        public DataTable GetAll()
        {
            return dal.GetAll();
        }

        public void Insert(string name, string size)
        {
            dal.Insert(name, size);
        }

        public void Update(int id, string name, string size)
        {
            dal.Update(id, name, size);
        }

        public void Delete(int id)
        {
            dal.Delete(id);
        }
    }
}