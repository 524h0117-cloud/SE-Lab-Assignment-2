﻿using DAL;
using System.Data;

namespace BLL
{
    public class UserBLL
    {
        DbHelper db = new DbHelper();

        public bool Login(string user, string pass)
        {
            string sql = $"SELECT * FROM Users WHERE UserName='{user}' AND Password='{pass}' AND Lock=0";

            DataTable dt = db.GetData(sql);

            return dt.Rows.Count > 0;
           
        }
    }
}