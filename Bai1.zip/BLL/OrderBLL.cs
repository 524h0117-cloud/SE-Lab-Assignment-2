﻿using DAL;
using System.Data;

namespace BLL
{
    public class OrderBLL
    {
        OrderDAL dal = new OrderDAL();

        public DataTable GetAgents()
        {
            return dal.GetAgents();
        }

        public DataTable GetItems()
        {
            return dal.GetItems();
        }

        public int InsertOrder(int agentId)
        {
            return dal.InsertOrder(agentId);
        }

        public void InsertDetail(int orderId, int itemId, int qty, float price)
        {
            dal.InsertDetail(orderId, itemId, qty, price);
        }
    }
}