﻿using System.Data;

namespace DAL
{
    public class AgentDAL
    {
        DbHelper db = new DbHelper();

        public DataTable GetAll()
        {
            return db.GetData("SELECT * FROM Agent");
        }

        public void Insert(string name, string address)
        {
            db.Execute($"INSERT INTO Agent VALUES(N'{name}', N'{address}')");
        }

        public void Update(int id, string name, string address)
        {
            db.Execute($"UPDATE Agent SET AgentName=N'{name}', Address=N'{address}' WHERE AgentID={id}");
        }

        public void Delete(int id)
        {
            db.Execute($"DELETE FROM Agent WHERE AgentID={id}");
        }
    }
}