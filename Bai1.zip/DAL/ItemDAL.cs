﻿using System.Data;

namespace DAL
{
    public class ItemDAL
    {
        DbHelper db = new DbHelper();

        public DataTable GetAll()
        {
            return db.GetData("SELECT * FROM Item");
        }

        public void Insert(string name, string size)
        {
            db.Execute($"INSERT INTO Item VALUES(N'{name}', N'{size}')");
        }

        public void Update(int id, string name, string size)
        {
            db.Execute($"UPDATE Item SET ItemName=N'{name}', Size=N'{size}' WHERE ItemID={id}");
        }

        public void Delete(int id)
        {
            db.Execute($"DELETE FROM Item WHERE ItemID={id}");
        }
    }
}