﻿using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System;

namespace DAL
{
    public class DbHelper
    {
        string connStr = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;

        public DataTable GetData(string query)
        {
            SqlConnection conn = new SqlConnection(connStr);
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        public int Execute(string query)
        {
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();
            SqlCommand cmd = new SqlCommand(query, conn);
            int result = cmd.ExecuteNonQuery();
            conn.Close();
            return result;
        }

        internal object GetScalar(string sql)
        {
            throw new NotImplementedException();
        }
    }
}