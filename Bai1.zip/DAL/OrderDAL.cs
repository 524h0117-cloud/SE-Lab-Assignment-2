﻿using System.Data;

namespace DAL
{
    public class OrderDAL
    {
        DbHelper db = new DbHelper();

        public int InsertOrder(int agentId)
        {
            string sql = $"INSERT INTO Orders VALUES(GETDATE(), {agentId}); SELECT SCOPE_IDENTITY();";
            return int.Parse(db.GetScalar(sql).ToString());
        }

        public void InsertDetail(int orderId, int itemId, int qty, float price)
        {
            string sql = $"INSERT INTO OrderDetail VALUES({orderId},{itemId},{qty},{price})";
            db.Execute(sql);
        }

        public DataTable GetAgents()
        {
            return db.GetData("SELECT * FROM Agent");
        }

        public DataTable GetItems()
        {
            return db.GetData("SELECT * FROM Item");
        }
    }
}