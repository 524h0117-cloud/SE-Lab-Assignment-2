use Exer2

CREATE TABLE Users (
    UserID INT IDENTITY(1,1) PRIMARY KEY,
    UserName NVARCHAR(50) NOT NULL UNIQUE,
    Email NVARCHAR(100) NOT NULL UNIQUE,
    [Password] NVARCHAR(100) NOT NULL,
    [Lock] BIT NOT NULL DEFAULT 0
);

CREATE TABLE Agent (
    AgentID INT IDENTITY(1,1) PRIMARY KEY,
    AgentName NVARCHAR(100) NOT NULL,
    Address NVARCHAR(200) NOT NULL
);

CREATE TABLE Item (
    ItemID INT IDENTITY(1,1) PRIMARY KEY,
    ItemName NVARCHAR(100) NOT NULL,
    Size NVARCHAR(50),
    Price DECIMAL(18,2) NOT NULL
);

CREATE TABLE [Order] (
    OrderID INT IDENTITY(1,1) PRIMARY KEY,
    OrderDate DATETIME NOT NULL DEFAULT GETDATE(),
    AgentID INT NOT NULL,
    CONSTRAINT FK_Order_Agent
        FOREIGN KEY (AgentID) REFERENCES Agent(AgentID)
);

CREATE TABLE OrderDetail (
    ID INT IDENTITY(1,1) PRIMARY KEY,
    OrderID INT NOT NULL,
    ItemID INT NOT NULL,
    Quantity INT NOT NULL,
    UnitAmount DECIMAL(18,2) NOT NULL,

    CONSTRAINT FK_OrderDetail_Order
        FOREIGN KEY (OrderID) REFERENCES [Order](OrderID),

    CONSTRAINT FK_OrderDetail_Item
        FOREIGN KEY (ItemID) REFERENCES Item(ItemID)
);

insert into Users values
('admin','admin@gmail.com','123',0),
('user1','u1@gmail.com','123',0)

insert into Agent values
('ABC Shop','Phnom Penh'),
('Lucky Store','Siem Reap'),
('Best Mart','Battambang')

insert into Item values
('Coca Cola','Can',1.2),
('Pepsi','Bottle',1.5),
('Water','500ml',0.8),
('Beer','Can',2.0)